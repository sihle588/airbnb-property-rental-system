import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.net.URL;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;
import java.util.Set;
import java.util.HashSet;

public class AirbnbLikePropertyRentalSystem {
    private JFrame frame;
    private Map<String, List<String>> reviewsMap = new HashMap<>();
    private Set<String> bookedProperties = new HashSet<>();
    private Map<String, JTextArea> propertyStatusMap = new HashMap<>();
    private Map<String, String> users = new HashMap<>();
    private String currentUser = null;

    public AirbnbLikePropertyRentalSystem() {
        SwingUtilities.invokeLater(this::showLoginScreen);
    }

    //  LOGIN & REGISTER  //
    private void showLoginScreen() {
        JFrame loginFrame = new JFrame("Login / Register - Airbnb-Like Property Rental System");
        loginFrame.setSize(400, 250);
        loginFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        loginFrame.setLayout(new GridLayout(5, 2, 10, 10));
        loginFrame.setLocationRelativeTo(null);

        JLabel userLabel = new JLabel("Username:");
        JTextField userField = new JTextField();
        JLabel passLabel = new JLabel("Password:");
        JPasswordField passField = new JPasswordField();

        JButton loginBtn = new JButton("Login");
        JButton registerBtn = new JButton("Register");

        JLabel messageLabel = new JLabel("", SwingConstants.CENTER);

        loginFrame.add(userLabel);
        loginFrame.add(userField);
        loginFrame.add(passLabel);
        loginFrame.add(passField);
        loginFrame.add(new JLabel(""));
        loginFrame.add(new JLabel(""));
        loginFrame.add(loginBtn);
        loginFrame.add(registerBtn);
        loginFrame.add(messageLabel);

        // Login button
        loginBtn.addActionListener(e -> {
            String username = userField.getText().trim();
            String password = new String(passField.getPassword());

            if (users.containsKey(username) && users.get(username).equals(password)) {
                currentUser = username;
                JOptionPane.showMessageDialog(loginFrame, "Welcome back, " + username + "!");
                loginFrame.dispose();
                SwingUtilities.invokeLater(this::showMainInterface);
            } else {
                JOptionPane.showMessageDialog(loginFrame, "Invalid username or password.");
            }
        });

        // Register button
        registerBtn.addActionListener(e -> {
            String username = userField.getText().trim();
            String password = new String(passField.getPassword());

            if (username.isEmpty() || password.isEmpty()) {
                JOptionPane.showMessageDialog(loginFrame, "Please enter both fields.");
                return;
            }

            if (users.containsKey(username)) {
                JOptionPane.showMessageDialog(loginFrame, "Username already exists.");
            } else {
                users.put(username, password);
                JOptionPane.showMessageDialog(loginFrame, "Account created successfully! Please login.");
            }
        });

        loginFrame.setVisible(true);
    }

    // MAIN INTERFACE  //
    private void showMainInterface() {
        frame = new JFrame("Airbnb-Like Property Rental System - Logged in as " + currentUser);
        frame.setSize(900, 700);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new BorderLayout());

        JPanel topPanel = new JPanel();
        JButton bookBtn = new JButton("Book Listing");
        JButton reviewBtn = new JButton("Leave Review");
        JButton viewReviewBtn = new JButton("View Reviews");
        JButton adminBtn = new JButton("Admin Dashboard");
        JButton logoutBtn = new JButton("Logout");

        topPanel.add(bookBtn);
        topPanel.add(reviewBtn);
        topPanel.add(viewReviewBtn);
        topPanel.add(adminBtn);
        topPanel.add(logoutBtn);
        frame.add(topPanel, BorderLayout.NORTH);

        JPanel propertyPanel = new JPanel();
        propertyPanel.setLayout(new BoxLayout(propertyPanel, BoxLayout.Y_AXIS));
        propertyPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // PROPERTY DATA
        String[][] properties = {
                 {"201", "The Rock Guesthouse Nelspruit", "Cape Town", "R1500", "https://cf.bstatic.com/xdata/images/hotel/max1024x768/473223203.jpg?k=99d45d1dbb1282a08a5f4ae306f72789e53d5229fdd6a9b67a97bb8865165498&o=&hp=1"},
                {"202", "Orange Hotel & Spa", "Cape Town", "R2000", "https://cf.bstatic.com/xdata/images/hotel/max1024x768/321558006.jpg?k=1b2964e22a956e81f8ce27c69eed438d88c11ec329b17629e0797e59eae7adc9&o="},
                {"203", "Nel on the Drive", "Camps Bay", "R950", "https://cf.bstatic.com/xdata/images/hotel/max1024x768/520165184.jpg?k=3cd2fe5ebfed2fcfad10b73678c6c573387c8f2a6d89b5efd9705b0fcc4fb32b&o="},
                {"204", "Wytham Manor House", "Kenilworth", "R2500", "https://cf.bstatic.com/xdata/images/hotel/max1024x768/548077198.jpg?k=ca32d69c5fc69f0799487c750d4c7dd5f2c1acebd072f642cbac95eeadc1c3c1&o="},
                {"205", "3 on Camps Bay", "Camps Bay", "R1800", "https://cf.bstatic.com/xdata/images/hotel/max1024x768/219372880.jpg?k=6524c2e05e99d42869db42bada2627092d9bbea60505c5e75cea49b43e954acd&o="},
                {"206", "Sandton Hotel", "Sandton", "R3000", "https://dynamic-media-cdn.tripadvisor.com/media/photo-o/16/33/71/75/paulshof-guest-house.jpg?w=1100&h=-1&s=1"},
                {"207", "Bluegum Hill Guesthouse", "Johannesburg", "R4000", "https://bluegumhill.co.za/wp-content/uploads/2019/04/Aerial-View-Bluegumhill-Guesthouse-1.jpg"},
                {"208", "Excellent Guesthouse", "Cape Town", "R3500", "https://d1zyr4xmqw3mni.cloudfront.net/image/1600/gallery/11207/property/155024.jpg"},
                {"209", "Feathers Guesthouse", "Middleburg", "R4200", "https://dynamic-media-cdn.tripadvisor.com/media/photo-o/0a/08/1a/7b/feathers-guesthouse.jpg?w=1400&h=-1&s=1"},
                {"210", "Mucklenuek Guesthouse", "Pretoria", "R5000", "http://yourneighbourhood.co.za/wp-content/uploads/2016/09/Muckleneuk-Guest-House-compressed.jpg"}
        };

        for (String[] prop : properties) {
            JPanel card = createPropertyCard(prop);
            propertyPanel.add(card);
            propertyPanel.add(Box.createRigidArea(new Dimension(0, 10)));
            card.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    showPropertyDetails(prop);
                }
            });
        }

        JScrollPane scrollPane = new JScrollPane(propertyPanel);
        frame.add(scrollPane, BorderLayout.CENTER);

        // BUTTON ACTIONS
        bookBtn.addActionListener(e -> bookProperty());
        reviewBtn.addActionListener(e -> leaveReview(properties));
        viewReviewBtn.addActionListener(e -> viewReviews(properties));
        adminBtn.addActionListener(e -> showAdminDashboard(properties));
        logoutBtn.addActionListener(e -> {
            frame.dispose();
            currentUser = null;
            SwingUtilities.invokeLater(this::showLoginScreen);
        });

        frame.setVisible(true);
    }

    // PROPERTY CARD //
    private JPanel createPropertyCard(String[] prop) {
        JPanel card = new JPanel();
        card.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        card.setLayout(new BorderLayout());
        card.setMaximumSize(new Dimension(800, 120));

        JLabel imgLabel = new JLabel();
        try {
            URL url = new URL(prop[4]);
            ImageIcon icon = new ImageIcon(url);
            Image img = icon.getImage().getScaledInstance(150, 100, Image.SCALE_SMOOTH);
            imgLabel.setIcon(new ImageIcon(img));
        } catch (Exception e) {
            imgLabel.setText("No Image");
            imgLabel.setHorizontalAlignment(JLabel.CENTER);
            imgLabel.setPreferredSize(new Dimension(150, 100));
        }
        card.add(imgLabel, BorderLayout.WEST);

        String status = bookedProperties.contains(prop[0]) ? "Booked" : "Available";
        JTextArea details = new JTextArea(
                "ID: " + prop[0] +
                        "\nProperty: " + prop[1] +
                        "\nLocation: " + prop[2] +
                        "\nPrice: " + prop[3] +
                        "\nStatus: " + status
        );
        details.setEditable(false);
        card.add(details, BorderLayout.CENTER);

        propertyStatusMap.put(prop[0], details);
        return card;
    }

    // BOOKING LIST //
    private void bookProperty() {
        String propertyId = JOptionPane.showInputDialog(frame, "Enter Property ID to book:");
        if (propertyId == null) return;

        if (propertyStatusMap.containsKey(propertyId)) {
            if (bookedProperties.contains(propertyId)) {
                JOptionPane.showMessageDialog(frame, "This property is already booked.");
            } else {
                bookedProperties.add(propertyId);
                JTextArea details = propertyStatusMap.get(propertyId);
                String text = details.getText().replace("Available", "Booked");
                details.setText(text);
                JOptionPane.showMessageDialog(frame, "Property ID " + propertyId + " booked successfully!");
            }
        } else {
            JOptionPane.showMessageDialog(frame, "Property ID not found.");
        }
    }

    //  REVIEWS //
    private void leaveReview(String[][] properties) {
        String propertyId = JOptionPane.showInputDialog(frame, "Enter Property ID to review:");
        if (propertyId == null) return;
        String review = JOptionPane.showInputDialog(frame, "Write your review:");
        if (review == null) return;

        reviewsMap.putIfAbsent(propertyId, new ArrayList<>());
        reviewsMap.get(propertyId).add(currentUser + ": " + review);

        JOptionPane.showMessageDialog(frame, "Review added successfully!");
    }

    private void viewReviews(String[][] properties) {
        String propertyId = JOptionPane.showInputDialog(frame, "Enter Property ID to view reviews:");
        if (propertyId == null) return;

        List<String> propertyReviews = reviewsMap.get(propertyId);
        if (propertyReviews == null || propertyReviews.isEmpty()) {
            JOptionPane.showMessageDialog(frame, "No reviews for this property yet.");
        } else {
            StringBuilder sb = new StringBuilder();
            for (String r : propertyReviews) sb.append("- ").append(r).append("\n");
            JOptionPane.showMessageDialog(frame, sb.toString(), "Reviews for Property " + propertyId, JOptionPane.INFORMATION_MESSAGE);
        }
    }

    // ADMIN DASHBOARD  //
    private void showAdminDashboard(String[][] properties) {
        StringBuilder sb = new StringBuilder("Admin Dashboard\n\nProperties:\n");
        for (String[] prop : properties) {
            String status = bookedProperties.contains(prop[0]) ? "Booked" : "Available";
            sb.append(prop[0]).append(": ").append(prop[1]).append(", ").append(prop[2])
                    .append(", ").append(prop[3]).append(", Status: ").append(status).append("\n");
        }
        sb.append("\nTotal Reviews Stored: ").append(reviewsMap.size());
        sb.append("\nTotal Booked Properties: ").append(bookedProperties.size());
        JOptionPane.showMessageDialog(frame, sb.toString(), "Admin Dashboard", JOptionPane.INFORMATION_MESSAGE);
    }

    // PROPERTY DETAILS  //
    private void showPropertyDetails(String[] prop) {
        JFrame detailFrame = new JFrame(prop[1]);
        detailFrame.setSize(500, 400);
        detailFrame.setLayout(new BorderLayout());

        JLabel imgLabel = new JLabel();
        try {
            URL url = new URL(prop[4]);
            ImageIcon icon = new ImageIcon(url);
            Image img = icon.getImage().getScaledInstance(400, 250, Image.SCALE_SMOOTH);
            imgLabel.setIcon(new ImageIcon(img));
        } catch (Exception e) {
            imgLabel.setText("No Image");
            imgLabel.setHorizontalAlignment(JLabel.CENTER);
            imgLabel.setPreferredSize(new Dimension(400, 250));
        }
        detailFrame.add(imgLabel, BorderLayout.NORTH);

        String status = bookedProperties.contains(prop[0]) ? "Booked" : "Available";
        JTextArea details = new JTextArea(
                "ID: " + prop[0] +
                        "\nProperty: " + prop[1] +
                        "\nLocation: " + prop[2] +
                        "\nPrice: " + prop[3] +
                        "\nStatus: " + status
        );
        details.setEditable(false);
        detailFrame.add(details, BorderLayout.CENTER);

        detailFrame.setVisible(true);
    }

    // MAIN //
    public static void main(String[] args) {
        new AirbnbLikePropertyRentalSystem();
    }
}